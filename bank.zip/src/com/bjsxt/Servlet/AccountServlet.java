package com.bjsxt.Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bjsxt.Service.AccountService;
import com.bjsxt.Service.Impl.AccountServiceImpl;
import com.bjsxt.pojo.Account;

@WebServlet("/transfer")
public class AccountServlet extends HttpServlet {
	AccountService accountservice = new AccountServiceImpl();

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		Account accIn = new Account();
		Account accOut = new Account();
		accIn.setName(req.getParameter("accInName"));
		accIn.setAccNo(req.getParameter("accInNo"));
		accOut.setAccNo(req.getParameter("accOutNo"));
		accOut.setPassword(Integer.parseInt(req.getParameter("accOutPassword")));
		accOut.setBalance(Integer.parseInt(req.getParameter("accOutBalance")));
		int index = accountservice.transfer(accIn, accOut);
		if(index==accountservice.SUCCESS) {
			resp.sendRedirect("log.jsp");
		}else {
			HttpSession session = req.getSession();
			session.setAttribute("code", index);
			resp.sendRedirect("/bank/error/error.jsp");
		}
		
	}
	

}
