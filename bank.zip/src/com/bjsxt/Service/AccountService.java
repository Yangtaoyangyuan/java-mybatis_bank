package com.bjsxt.Service;

import java.io.IOException;

import com.bjsxt.pojo.Account;

public interface AccountService {
	/*
	 * 汇款方账号和密码不匹配
	 * */
	int ACCOUNT_PASSWORD_NOT_MATCH = 1;
	/*
	 * 收款方账号和用户名不匹配
	 * */
	int ACCOUNT_NAME_NOT_MATCH = 2;
	/*
	 * 汇款方余额不足
	 * */
	int ACCOUNT_BALANCE_NOT_ENOUGH = 3;
	/*
	 * 转账成功
	 * */
	int SUCCESS = 4;
	/*
	 * 转账失败
	 * */
	int FAILED = 5;
	int transfer(Account accIn,Account accOut)throws IOException;

}
