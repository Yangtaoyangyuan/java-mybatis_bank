package com.bjsxt.Service.Impl;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.bjsxt.Service.AccountService;
import com.bjsxt.pojo.Account;

public class AccountServiceImpl implements AccountService {

	@Override
	public int transfer(Account accIn, Account accOut) throws IOException {
		
		InputStream is = Resources.getResourceAsStream("mybatis.xml");
		SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(is);
		SqlSession session = factory.openSession();
		Account accSelOut = session.selectOne("com.bjsxt.AccountMapper.selByAccnoAndPass",accOut);
		if(accSelOut!=null) {
			if(accSelOut.getBalance()>=accOut.getBalance()) {
				Account accSelIn = session.selectOne("com.bjsxt.AccountMapper.selByAccnoAndName", accIn);
				if(accSelIn!=null) {
					accIn.setBalance(accOut.getBalance());
					accOut.setBalance(-accOut.getBalance());
					int index = session.update("com.bjsxt.AccountMapper.updBalanceByAccno", accOut);
					index += session.update("com.bjsxt.AccountMapper.updBalanceByAccno", accIn);
					if(index==2) {
						session.commit();
						session.close();
						return SUCCESS;
					}else {
						session.rollback();
						session.close();
						return FAILED;
					}
				}else {
					return ACCOUNT_NAME_NOT_MATCH;
				}
			}else {
				return ACCOUNT_BALANCE_NOT_ENOUGH;
			}	
		}else {
			return ACCOUNT_PASSWORD_NOT_MATCH;
		}
	}	
}
